// You can find instructions for this file here:
// http://www.geocities.com/marcelino_martins/ftv2instructions.html

// Decide if the names are links or just the icons
USETEXTLINKS = 1  //replace 0 with 1 for hyperlinks

// Decide if the tree is to start all open or just showing the root folders
STARTALLOPEN = 0 //replace 0 with 1 to show the whole tree


foldersTree = gFld("<i>Been There</i>", "startPage.html")
	aux1 = insFld(foldersTree, gFld("Europe", "http://www.geocities.com/marcelino_martins/ftexample/beenthere_europe.gif"))
	      aux2 = insFld(aux1, gFld("United Kingdom", "http://www.geocities.com/marcelino_martins/ftexample/beenthere_unitedkingdom.gif"))
		      aux3 = insFld(aux2, gFld("Scotland", "http://www.geocities.com/marcelino_martins/ftexample/beenthere_scotland.jpg"))
				insDoc(aux3, gLnk(2, "Edinburgh", "www.geocities.com/marcelino_martins/ftexample/beenthere_edinburgh.gif"))
 			insDoc(aux2, gLnk(2, "London", "www.geocities.com/marcelino_martins/ftexample/beenthere_london.jpg"))
	      aux2 = insFld(aux1, gFld("Germany", "http://www.geocities.com/marcelino_martins/ftexample/beenthere_germany.gif"))
 			insDoc(aux2, gLnk(2, "Munich", "www.geocities.com/marcelino_martins/ftexample/beenthere_munich.jpg"))
	      aux2 = insFld(aux1, gFld("Greece", "http://www.geocities.com/marcelino_martins/ftexample/beenthere_greece.gif"))
 			insDoc(aux2, gLnk(2, "Athens", "www.geocities.com/marcelino_martins/ftexample/beenthere_athens.jpg"))
	      aux2 = insFld(aux1, gFld("Italy", "http://www.geocities.com/marcelino_martins/ftexample/beenthere_italy.gif"))
		      aux3 = insFld(aux2, gFld("Tuscany", "http://www.geocities.com/marcelino_martins/ftexample/beenthere_tuscany.gif"))
				insDoc(aux3, gLnk(2, "Florence", "www.geocities.com/marcelino_martins/ftexample/beenthere_florence.jpg"))
				insDoc(aux3, gLnk(2, "Pisa", "www.geocities.com/marcelino_martins/ftexample/beenthere_pisa.jpg"))
			insDoc(aux2, gLnk(2, "Rome", "www.geocities.com/marcelino_martins/ftexample/beenthere_rome.jpg"))
	      aux2 = insFld(aux1, gFld("Portugal", "http://www.geocities.com/marcelino_martins/ftexample/beenthere_portugal.gif"))
 			insDoc(aux2, gLnk(2, "Lisboa", "www.geocities.com/marcelino_martins/ftexample/beenthere_lisbon.jpg"))
     aux1 = insFld(foldersTree, gFld("America", "http://www.geocities.com/marcelino_martins/ftexample/beenthere_america.gif"))
	      aux2 = insFld(aux1, gFld("Canada", "http://www.geocities.com/marcelino_martins/ftexample/beenthere_canada.gif"))
 			insDoc(aux2, gLnk(2, "Montreal", "www.geocities.com/marcelino_martins/ftexample/beenthere_montreal.jpg"))
	      aux2 = insFld(aux1, gFld("United States", "http://www.geocities.com/marcelino_martins/ftexample/beenthere_unitedstates.gif"))
 			insDoc(aux2, gLnk(2, "Boston", "www.geocities.com/marcelino_martins/ftexample/beenthere_boston.jpg"))
 			insDoc(aux2, gLnk(2, "New York", "www.geocities.com/marcelino_martins/ftexample/beenthere_newyork.jpg"))
 			insDoc(aux2, gLnk(2, "Washington", "www.geocities.com/marcelino_martins/ftexample/beenthere_washington.jpg"))

