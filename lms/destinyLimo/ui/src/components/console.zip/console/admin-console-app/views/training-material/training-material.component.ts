import { Component } from '@angular/core';

@Component({
  selector: 'app-training-material',
  standalone: true,
  imports: [],
  templateUrl: './training-material.component.html',
  styleUrl: './training-material.component.css'
})
export class TrainingMaterialComponent {

}
